﻿global using JetBrains.Annotations;
global using System.Runtime.CompilerServices;